package com.sibiservicesapp.loginregistrationusingroom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class RegistrationActivity extends AppCompatActivity {

    EditText et_username,et_serialno;
    EditText et_pass,et_cmpnynm,et_ipaddress;
    Button btn_signup;
    Button btnlogin;
    UserDao userDao;
    List<User> mylist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_registration );

        getWindow().setFlags( WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN );
        getSupportActionBar().hide();

        et_username = findViewById( R.id.username );
        et_pass = findViewById( R.id.password );
        et_serialno = findViewById( R.id.serialno );
        et_cmpnynm = findViewById( R.id.cmpnyname);
        et_ipaddress = findViewById( R.id.ipaddress );

        btn_signup = findViewById( R.id.btnReg );
        btnlogin = findViewById( R.id.btnlogin );
        UserDatabase db = UserDatabase.getInstance(this.getApplication());
        userDao = db.userDao();
        btnlogin.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent( RegistrationActivity.this,MainActivity.class ) );
            }
        } );

        btn_signup.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = et_username.getText().toString().trim();
                String pass = et_pass.getText().toString().trim();
                String serialNo = et_serialno.getText().toString().trim();
                String cmpnyName = et_cmpnynm.getText().toString().trim();
                String ipaddrs = et_ipaddress.getText().toString().trim();
                if (username.isEmpty() || pass.isEmpty()) {
                    Toast.makeText( RegistrationActivity.this, "Enter all fields", Toast.LENGTH_SHORT ).show();
                } else {
                    new adduserAsyncTask( username, pass ,serialNo,cmpnyName,ipaddrs).execute();
                }

            }
        } );

    }


    public class adduserAsyncTask extends AsyncTask<Void, Void, Boolean> {
        private String username;
        private String pass;
        private String serialNo;
        private String CmpnyName;
        private String ipAddrs;

        private User new_user;
        UserDao userDao;
        private Boolean is_new;

        public adduserAsyncTask(String username, String pass,String serial,String cmpny,String ipAddrs) {
            this.username = username;
            this.pass = pass;
            this.serialNo = serial;
            this.CmpnyName = cmpny;
            this.ipAddrs = ipAddrs;

            UserDatabase db = UserDatabase.getInstance( RegistrationActivity.this.getApplication() );
            this.userDao = db.userDao();
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            new_user = userDao.getUser( username, pass );
            if (new_user == null) {
                userDao.insertUser( new User( username, pass ,serialNo,CmpnyName,ipAddrs) );
                is_new = true;
            } else {
                is_new = false;
            }
            return is_new;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            if (is_new)
            {
                Toast.makeText(RegistrationActivity.this,"User Added",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegistrationActivity.this,MainActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(RegistrationActivity.this,"User Already Exists",Toast.LENGTH_SHORT).show();
            }
        }

    }
}
