package com.sibiservicesapp.loginregistrationusingroom;

import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity(tableName = "user_table")
public class User {

    private String username;
    private String password;
    private String serailno;
    private String cmpnyName;
    private String ipAddress;



    @PrimaryKey(autoGenerate = true)
    private Integer id;

//    public User(String username, String password) {
//        this.username = username;
//        this.password = password;
//    }

    public User(String username, String password, String serailno, String cmpnyName, String ipAddress) {
        this.username = username;
        this.password = password;
        this.serailno = serailno;
        this.cmpnyName = cmpnyName;
        this.ipAddress = ipAddress;
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSerailno() {
        return serailno;
    }

    public void setSerailno(String serailno) {
        this.serailno = serailno;
    }

    public String getCmpnyName() {
        return cmpnyName;
    }

    public void setCmpnyName(String cmpnyName) {
        this.cmpnyName = cmpnyName;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
