package com.sibiservicesapp.loginregistrationusingroom;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText et_username;
    EditText et_pass;
    Button btn_signup;
    Button btnlogin;
    UserDao userDao;
    List<User> mylist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        et_username = findViewById( R.id.username );
        et_pass = findViewById( R.id.password );
        btn_signup = findViewById( R.id.btnReg );
        btnlogin = findViewById( R.id.btnlogin );

        getWindow().setFlags( WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN );
        getSupportActionBar().hide();

        UserDatabase db = UserDatabase.getInstance( this.getApplication() );
        userDao = db.userDao();
        btnlogin.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name;
                String pass;
                name = et_username.getText().toString().trim();
                pass = et_pass.getText().toString().trim();

                if (name.isEmpty() || pass.isEmpty())
                {
                    Toast.makeText(MainActivity.this,"Enter Username and Password",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    checkAsycTask task = new checkAsycTask(MainActivity.this.getApplication(),name,pass);
                    task.execute();
                }

            }
        } );

        btn_signup.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent( MainActivity.this,RegistrationActivity.class ) );
            }
        } );

    }

    public  class checkAsycTask extends AsyncTask<User,Void,User>
    {
        private UserDao userDao;
        private String name;
        private String pass;
        User user;

        public checkAsycTask(Application application, String name, String pass) {
            this.name = name;
            this.pass = pass;
            UserDatabase db = UserDatabase.getInstance(application);
            userDao = db.userDao();
        }

        @Override
        protected User doInBackground(User... users) {

            user = userDao.getUser(name,pass);
            return user;
        }

        @Override
        protected void onPostExecute(User user) {
            super.onPostExecute(user);
            if (user == null)
            {
                Toast.makeText(MainActivity.this,"User not found!",Toast.LENGTH_SHORT).show();
            }
            else {
                Intent intent = new Intent(MainActivity.this, HomeScreen.class);
                startActivity(intent);
            }
        }
    }

    public  class showuserAsyctask extends  AsyncTask<Void,Void,Void>
    {
        UserDao userDao;

        public showuserAsyctask() {
            UserDatabase db = UserDatabase.getInstance(MainActivity.this.getApplication());
            this.userDao = db.userDao();
        }

        @SuppressLint("WrongThread")
        @Override
        protected Void doInBackground(Void... voids) {
        String str = null;
            mylist = userDao.getAllUsers();
            for (int i=0;i<mylist.size();i++)
            {

                str = str +  mylist.get(i).getUsername();
//                Log.d("______","id       : " + mylist.get(i).getId());
//                Log.d("______","usernaem : " + mylist.get(i).getUsername());
//                Log.d("______","password : " + mylist.get(i).getPassword());
            }

            TextView forgot;
            forgot =(TextView) findViewById( R.id.forgot );
            forgot.setText( str );
            return null;
        }
    }
}
